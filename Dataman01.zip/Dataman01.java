package dataman01;

import java.util.Scanner;

public class Dataman01 {

    public static void main(String[] args) {
        MainMenu();
        AnswerChecker();
        MemoryBank();
        NumberGuesser();
    }

    static void MainMenu() {
        System.out.println("Welcome to the Calculator program.");
        System.out.println("1. Answer Checker");
        System.out.println("2. Memory Bank");
        System.out.println("3. Number Guesser");
        System.out.println("4. Exit");
        Scanner keyboard = new java.util.Scanner(System.in);
        int userChoice;
        System.out.println("Enter a number:");
        userChoice = keyboard.nextInt();
        switch (userChoice) {
            case 1:
                AnswerChecker();
                break;
            case 2:
                MemoryBank();
                break;
            case 3:
                NumberGuesser();
                break;
            case 4:
                System.out.println("Goodbye!");
                System.exit(0);
            default:
                // This is a catch so if the user inputs a wrong command and will repeat this until they input a correct one
                System.out.println("You have entered an invalid input, try again.");
                MainMenu();
                break;
        }
    }

    static void AnswerChecker() {
        double num1 = Math.floor(Math.random() * 101);
        double num2 = Math.floor(Math.random() * 101);
        double total = num1 + num2;
        int answer, userChoice;

        Scanner keyboard = new java.util.Scanner(System.in);
        System.out.println("What is " + num1 + " + " + num2 + "?");
        answer = keyboard.nextInt();
        if (answer == total) {
            System.out.println("That is correct! " + total + " is the sum of those two numbers");
            System.out.println("Would you like to try another problem?");
            System.out.println("1. Repeat");
            System.out.println("2. Main Menu");
            System.out.println("Please Enter a number:");
            userChoice = keyboard.nextInt();
            if (userChoice == 1) {
                AnswerChecker();
            } else if (userChoice == 2) {
                MainMenu();
            }
        } else if (answer != total) {
            System.out.println("What is " + num1 + " + " + num2 + "?");
            answer = keyboard.nextInt();
            if (answer == total) {
                System.out.println("That is correct! " + total + " is the sum of those two numbers");
                System.out.println("Would you like to try another problem?");
                System.out.println("1. Repeat");
                System.out.println("2. Main Menu");
                System.out.println("Please Enter a number:");
                userChoice = keyboard.nextInt();
                if (userChoice == 1) {
                    AnswerChecker();
                } else if (userChoice == 2) {
                    MainMenu();
                }
            } else if (answer != total) {
                System.out.println("What is " + num1 + " + " + num2 + "?");
                answer = keyboard.nextInt();
                if (answer == total) {
                    System.out.println("That is correct! " + total + " is the sum of those two numbers");
                    System.out.println("Would you like to try another problem?");
                    System.out.println("1. Repeat");
                    System.out.println("2. Main Menu");
                    System.out.println("Please Enter a number:");
                    userChoice = keyboard.nextInt();
                    if (userChoice == 1) {
                        AnswerChecker();
                    } else if (userChoice == 2) {
                        MainMenu();
                    }
                } else if (answer != total) {
                    System.out.println("That is incorrect, the answer is " + total);
                    System.out.println("Would you like to try another problem?");
                    System.out.println("1. Repeat");
                    System.out.println("2. Main Menu");
                    System.out.println("Please Enter a number:");
                    userChoice = keyboard.nextInt();
                    if (userChoice == 1) {
                        AnswerChecker();
                    } else if (userChoice == 2) {
                        MainMenu();
                    }
                }
            }
        }
    }

    static void MemoryBank() {
        Scanner keyboard = new java.util.Scanner(System.in);
        int userChoice;
        System.out.println("1: Repeat");
        System.out.println("2: Main Menu");
        System.out.println("Enter a number:" );
        userChoice = keyboard.nextInt();
        // This will loop around if the user chooses 1 to continue adding or go back to the main menu if they input 2 
        if (userChoice ==1) {
            MemoryBank();
        } else if (userChoice ==2){
            MainMenu();
        }
    }

    static void NumberGuesser() {
       Scanner keyboard = new java.util.Scanner(System.in);
        int userChoice;
        System.out.println("1: Repeat");
        System.out.println("2: Main Menu");
        System.out.println("Enter a number:" );
        userChoice = keyboard.nextInt();
        if (userChoice ==1) {
            NumberGuesser();
        } else if (userChoice ==2){
            MainMenu();
        }
    }
}

