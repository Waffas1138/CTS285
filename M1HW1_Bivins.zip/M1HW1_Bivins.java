package m1hw1_bivins;

/**
 * Travis Bivins
 * CTS-285
 * 8/16/21
 * This is a text based Calculator that the user will be able to navigate 
 */
import java.util.Scanner;
public class M1HW1_Bivins {

    
    public static void main(String[] args) {
        mainMenu();
        addition();
        subtraction();
        division();
        multiplication();
    }
    static void mainMenu(){
       System.out.println("Welcome to the Calculator program.");
       System.out.println("1. Add");
       System.out.println("2. Subtract");
       System.out.println("3. Divide.");
       System.out.println("4. Multiply");
       System.out.println("5. Exit");
       Scanner keyboard = new java.util.Scanner(System.in);
        double userChoice;
        System.out.println("Enter a number:" );
        userChoice = keyboard.nextDouble();
        if (userChoice == 1 ){
            addition();
        } else if(userChoice == 2){
            subtraction();
        } else if(userChoice == 3) {
            division();
        } else if(userChoice == 4){
            multiplication();
        } else if (userChoice == 5){
            System.exit(0); 
        } else{
            System.out.println("You have entered an invalid input, try again.");
        }
    }
    static void addition(){
        Scanner keyboard = new java.util.Scanner(System.in);
        double userChoice;
        int number1, number2, totalSum;
        System.out.println("Add");
        System.out.println("Enter a number:" );
        number1 = keyboard.nextInt();
        System.out.println("Enter a number:" );
        number2 = keyboard.nextInt();
        
        totalSum = number1 + number2;
        System.out.println(number1 + " + " + number2 + " = " + totalSum);
        System.out.println("1. Repeat");
        System.out.println("2. Main Menu");
        System.out.println("Enter a number:" );
        userChoice = keyboard.nextDouble();
        if (userChoice ==1) {
            addition();
        } else if (userChoice ==2){
            mainMenu();
        }
    }
    static void subtraction(){
        Scanner keyboard = new java.util.Scanner(System.in);
        double userChoice;
        int number1, number2, totalSum;
        System.out.println("Subtraction");
        System.out.println("Enter a number:" );
        number1 = keyboard.nextInt();
        System.out.println("Enter a number:" );
        number2 = keyboard.nextInt();
        
        totalSum = number1 - number2;
        System.out.println(number1 + " - " + number2 + " = " + totalSum);
        System.out.println("1. Repeat");
        System.out.println("2. Main Menu");
        System.out.println("Enter a number:" );
        userChoice = keyboard.nextDouble();
        if (userChoice ==1) {
            subtraction();
        } else if (userChoice ==2){
            mainMenu();
        }
    }
    static void division(){
        Scanner keyboard = new java.util.Scanner(System.in);
        double userChoice;
        int number1, number2, totalSum;
        System.out.println("Division");
        System.out.println("Enter a number:" );
        number1 = keyboard.nextInt();
        System.out.println("Enter a number:" );
        number2 = keyboard.nextInt();
        
        totalSum = number1 / number2;
        System.out.println(number1 + " / " + number2 + " = " + totalSum);
        System.out.println("1. Repeat");
        System.out.println("2. Main Menu");
        System.out.println("Enter a number:" );
        userChoice = keyboard.nextDouble();
        if (userChoice ==1) {
            division();
        } else if (userChoice ==2){
            mainMenu();
        }
    }
    static void multiplication(){
        Scanner keyboard = new java.util.Scanner(System.in);
        double userChoice;
        int number1, number2, totalSum;
        System.out.println("Multiply");
        System.out.println("Enter a number:" );
        number1 = keyboard.nextInt();
        System.out.println("Enter a number:" );
        number2 = keyboard.nextInt();
        
        totalSum = number1 / number2;
        System.out.println(number1 + " * " + number2 + " = " + totalSum);
        System.out.println("1. Repeat");
        System.out.println("2. Main Menu");
        System.out.println("Enter a number:" );
        userChoice = keyboard.nextDouble();
        if (userChoice ==1) {
            multiplication();
        } else if (userChoice ==2){
            mainMenu();
        }
    }
}
