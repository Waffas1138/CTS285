﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilites;
using Utilities;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            while (World.exit == false)
            {
                Console.WriteLine(StandardMesages.DisplayRoom(World.index));
                Console.WriteLine("");
                Console.WriteLine(StandardMesages.DisplayMenU()); 
                Console.Write(StandardMesages.DisplayMenuPrompt());
                switch (Console.ReadLine().ToLower()) 
                {
                    case "rooms":
                        ForEach.DisplayValues(World.rooms);
                        break;
                    case "weapons":
                        Console.WriteLine("ButterFlyKnife");
                        WeaponsInfo.ButterFlyKnife();
                        Console.WriteLine("");
                        Console.WriteLine("Claymore");
                        WeaponsInfo.Claymore();
                        Console.WriteLine("");
                        Console.WriteLine("Golden Gun");
                        WeaponsInfo.GoldenGun();
                        Console.WriteLine("");
                        Console.WriteLine("Revolver");
                        WeaponsInfo.Revolver();
                        Console.WriteLine("");
                        Console.WriteLine("Shield");
                        WeaponsInfo.Shield();
                        Console.WriteLine("");
                        Console.WriteLine("Shotgun");
                        WeaponsInfo.Shotgun();
                        Console.WriteLine("");
                        break;
                    case "potions":
                        ForEach.DisplayValues(World.potions);
                        break;
                    case "treasure":
                        ForEach.DisplayValues(World.treasures);
                        break;
                    case "items":
                        ForEach.DisplayValues(World.items);
                        break;
                    case "exit":
                        World.exit = true; // exits the program
                        break;

                    default:
                        Console.WriteLine(StandardMesages.DisplayMenuError());
                        break;
                }
                Console.WriteLine("");
            }
        }
    }
}
