﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public static class WeaponsInfo
    {
        public static List<string> weapons = new List<string>() { "Butterfly Knife", "Shield", "Shotgun", "double action revolver", "Claymore Sword", "Golden Gun" };
        public static void ButterFlyKnife()
        {
            Console.WriteLine("A simple but exquiste knife that can be used when upclose to the enemy to deal damage and has a chance to cause bleeding");
        }
        public static void Shield()
        {
            Console.WriteLine("Your trusty shield, it's helped you through previous struggles but now let's see how much it can sustain here. \n Your shield will reduce the damage taken from an attack");
        }
        public static void Shotgun()
        {
            Console.WriteLine("When you're close to the enemy and need something that'll get the job done that's what your shotgun is for. \n It has a higher chance to crit than usual while dealing " +
                "alot of damage as well");
        }
        public static void Revolver()
        {
            Console.WriteLine("The trusty six-shooter as some may call it, when in a bind don't be afraid to draw this revoler out \n it'll do in a pinch and can be shot in rapid succession for a fast kill.");
        }
        public static void Claymore()
        {
            Console.WriteLine("For when you really want to just go chargin head on pull out your Claymore you found and start swinging away, \n by using this you will have a high chance to cause bleeding " +
                "\n to the enemy if they didn't die from the intial swing");
        }
        public static void GoldenGun()
        {
            Console.WriteLine("Have you ever wanted a golden gun that is also on fire? Well if not too bad that's what this is. \n Nothing can stand in the way of a flaming gun so have fun inflicting heavy damage" +
                " \n and also inflicting burn on the enemy, if the first shot won't kill them then the fire is sure to do the job for you. Just don't miss with this");
        }
    }
}
